package com.company;

public class Boss {
    private int life;
    private int damage;
    private String armor;

    public int getLife() {

        return life;
    }

    public int getDamage() {

        return damage;
    }

    public String getArmor() {
        return armor;
    }

    public void setLife(int life) {

        this.life = life;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public void setArmor(String armor) {
        this.armor = armor;
    }
}




