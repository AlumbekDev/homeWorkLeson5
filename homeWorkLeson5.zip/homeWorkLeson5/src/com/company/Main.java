package com.company;

public class Main {

    public static void main(String[] args) {
        createHeroes();
        for (Hero var : createHeroes()) {
            System.out.println("Здоровье героев " + " " + var.getHealth() + " AttackType " + " " + var.getSuperpower() + " Damage " + " " + var.getDamage());

        }
        {
            Hero hero = new Hero(300, 20, "Owns lightning");
            Hero Old = new Hero(15, 260);
            Boss strong = new Boss();
            strong.setLife(400);
            strong.setDamage(53);
            strong.setArmor("Owns lightning");
            System.out.println(strong.getLife() + " " + strong.getDamage() + " " + strong.getArmor());

        }
        public static Hero[] createHeroes () {
            Hero Hedgehog = new Hero(200, 35, "Lava from the ground");
            Hero squirrel = new Hero(20, 140, " Teleportation");
            Hero wolf = new Hero(170, 42, "Assassin mode");

            Hero[] hilt = new Hero[3];
            hilt[0] = Hedgehog;
            hilt[1] = squirrel;
            hilt[2] = wolf;
            return hilt;
        }
    }
}
